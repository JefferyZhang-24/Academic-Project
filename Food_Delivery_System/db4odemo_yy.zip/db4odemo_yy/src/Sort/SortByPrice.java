/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sort;

import Business.Restaurant.Menu;
import java.util.Comparator;

/**
 *
 * @author Kiksuya
 */
public class SortByPrice implements  Comparator<Menu>{
     public SortByPrice() {
        super();
    }
    @Override
    public int compare(Menu o1, Menu o2) {
        
        return (int) (o1.getPrice()-o2.getPrice());
        
    } 
}
