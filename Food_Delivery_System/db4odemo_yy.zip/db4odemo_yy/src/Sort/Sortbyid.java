/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sort;
import Business.Restaurant.Menu;
import java.util.Comparator;
/**
 *
 * @author Kiksuya
 */
public class Sortbyid implements  Comparator<Menu>{
    public Sortbyid() {
        super();
    }
    @Override
    public int compare(Menu o1, Menu o2) {
        
        return o1.getMenuId()-o2.getMenuId();
        
    } 
}
