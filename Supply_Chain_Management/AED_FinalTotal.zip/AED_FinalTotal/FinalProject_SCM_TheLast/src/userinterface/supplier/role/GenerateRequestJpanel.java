package userinterface.supplier.role;

import business.employee.Employee;
import business.enterprise.Enterprise;
import business.organization.GenerateOrg;
import business.organization.Organization;
import business.organization.WorkerMngOrg;
import business.organization.LogisticsOrg;
import business.useraccount.UserAccount;
import business.workqueue.ProductRequest;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author lhm
 */
public class GenerateRequestJpanel extends javax.swing.JPanel {

    private JPanel userJpanel;
    private UserAccount userAccount;
    private Enterprise enterprise;
    private Employee employee;
    private ProductRequest productRequest;
    
    public GenerateRequestJpanel(JPanel userJpanel, UserAccount userAccount, Enterprise enterprise, /*Employee  employee, */ProductRequest request) {
        this.userJpanel = userJpanel;
        this.userAccount = userAccount;
        this.enterprise = enterprise;
//        this.employee = employee;
        this.productRequest = request;
        initComponents();
        valueJlabel.setText(enterprise.getEnterpriseName());
//        nameJlabel.setText(employee.getName());
        nameJlabel.setText(userAccount.getUsername());

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        enterpriseJlabel = new javax.swing.JLabel();
        valueJlabel = new javax.swing.JLabel();
        titleJlabel = new javax.swing.JLabel();
        backJButton = new javax.swing.JButton();
        messageJtext = new javax.swing.JTextField();
        submitJButton = new javax.swing.JButton();
        messageJlabel = new javax.swing.JLabel();
        workerNameJlabel = new javax.swing.JLabel();
        nameJlabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(153, 153, 153));

        enterpriseJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        enterpriseJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        enterpriseJlabel.setText("Enterprise:");
        enterpriseJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        valueJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        valueJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        valueJlabel.setText("value");
        valueJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        titleJlabel.setFont(new java.awt.Font("Adobe Caslon Pro", 2, 48)); // NOI18N
        titleJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJlabel.setText("Generate Request");
        titleJlabel.setMaximumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setMinimumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setPreferredSize(new java.awt.Dimension(170, 30));

        backJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        backJButton.setText("< Back");
        backJButton.setMaximumSize(new java.awt.Dimension(120, 30));
        backJButton.setMinimumSize(new java.awt.Dimension(120, 30));
        backJButton.setPreferredSize(new java.awt.Dimension(120, 30));
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });

        messageJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        messageJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        messageJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        messageJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        messageJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        submitJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        submitJButton.setText("Submit");
        submitJButton.setMaximumSize(new java.awt.Dimension(90, 30));
        submitJButton.setMinimumSize(new java.awt.Dimension(90, 30));
        submitJButton.setPreferredSize(new java.awt.Dimension(90, 30));
        submitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitJButtonActionPerformed(evt);
            }
        });

        messageJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        messageJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messageJlabel.setText("Request Message:");
        messageJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        messageJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        messageJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        workerNameJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        workerNameJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        workerNameJlabel.setText("Worker Name:");
        workerNameJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        workerNameJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        workerNameJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        nameJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        nameJlabel.setForeground(new java.awt.Color(204, 204, 204));
        nameJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nameJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        nameJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        nameJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon("/Users/zhanghaojie/Desktop/AED TeamMosaic/Picture_SCM/equality_sneaker.gif")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(messageJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addComponent(messageJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(workerNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(38, 38, 38)
                                                .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(nameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)))))
                .addContainerGap(675, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addComponent(workerNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(nameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(messageJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(messageJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(233, 233, 233))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed
        userJpanel.remove(this);
        Component[] componentArray = userJpanel.getComponents();
        Component component = componentArray[componentArray.length - 1];
        GenerateManagerRoleInterface generateInterface = (GenerateManagerRoleInterface) component;
        generateInterface.populateRequestTable();
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        layout.previous(userJpanel);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void submitJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitJButtonActionPerformed
        String message = messageJtext.getText();
        if (message == null || message.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please input the request message", "SUBMIT", JOptionPane.ERROR_MESSAGE);
            return;
        }
        this.productRequest.setMessage(message);
        ArrayList<Organization> orgList = new ArrayList<Organization>();
        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
//            if (organization instanceof WorkerMngOrg) {
            if (/*organization instanceof WorkerMngOrg ||*/ organization instanceof LogisticsOrg  ) {
                orgList.add(organization);
           //     organization.getWorkQueue().getWorkRequestList().add(productRequest);
            }
        }
        
        for (Organization organization : orgList) {
            organization.getWorkQueue().getWorkRequestList().add(this.productRequest);
            for (UserAccount ua : organization.getUserAccountDirectory().getUserAccountList()) {
                ua.getWorkQueue().getWorkRequestList().add(this.productRequest);
                //this.productRequest.setReceiver(ua); //set receiver
            }
        }
        
        /*
        for (Organization organization : orgList) {
            organization.getWorkQueue().getWorkRequestList().add(this.productRequest);
        }
*/
        System.out.println(orgList);
        userAccount.getWorkQueue().getWorkRequestList().add(this.productRequest);
        this.productRequest.setReceiver(userAccount);
        JOptionPane.showMessageDialog(null, "Submit OK!", "SUMBIT", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_submitJButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backJButton;
    private javax.swing.JLabel enterpriseJlabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel messageJlabel;
    private javax.swing.JTextField messageJtext;
    private javax.swing.JLabel nameJlabel;
    private javax.swing.JButton submitJButton;
    private javax.swing.JLabel titleJlabel;
    private javax.swing.JLabel valueJlabel;
    private javax.swing.JLabel workerNameJlabel;
    // End of variables declaration//GEN-END:variables
}
