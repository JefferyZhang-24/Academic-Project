package userinterface.supplier.role;

import business.employee.Employee;
import business.enterprise.Enterprise;
import business.enterprise.factory.Cargo;
import business.organization.Organization;
import business.organization.Organization.OrgType;
import business.useraccount.UserAccount;
import business.workqueue.OrderRequest;
import business.workqueue.ProductRequest;
import business.workqueue.WorkRequest;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lhm
 */
public class GenerateManagerRoleInterface extends javax.swing.JPanel {

    private JPanel userJpanel;
    private UserAccount userAccount;
    private Enterprise enterprise;
    private Organization org;

    public GenerateManagerRoleInterface(JPanel userJpanel, UserAccount userAccount, Enterprise enterprise, Organization org) {
        this.userJpanel = userJpanel;
        this.userAccount = userAccount;
        this.enterprise = enterprise;
        this.org = org;
        initComponents();
        valueJlabel.setText(enterprise.getEnterpriseName());
        orgValueJlabel.setText(org.getName());
        populateRequestTable();
 //       populateWorkerTable();
        popWorkerComboBox();
    }

    public void populateRequestTable() {
        DefaultTableModel model = (DefaultTableModel) workRequestJtable.getModel();
        model.setRowCount(0);
        for (WorkRequest request : userAccount.getWorkQueue().getWorkRequestList()) {
            if (((ProductRequest) request).getCargoDirectory().getCargoList().size() == 0) {
                Object[] row = new Object[6];
                row[0] = request;
                row[1] = ((ProductRequest) request).getReceiveEnterprise();
                row[2] = request.getReceiver() == null ? "not assign" : request.getReceiver();
                row[5] = request.getMessage();
                model.addRow(row);
                continue;
            }
            for (Cargo cargo : ((ProductRequest) request).getCargoDirectory().getCargoList()) {
                Object[] row = new Object[6];
                row[0] = request;
                row[1] = ((ProductRequest) request).getReceiveEnterprise();
                row[2] = request.getReceiver() == null ? "not assign" : request.getReceiver();
                row[3] = cargo.getCargoName();
                row[4] = cargo.getQuantity();
                row[5] = request.getMessage();
                model.addRow(row);
            }
        }
    }
/*
    public void populateWorkerTable() {
        DefaultTableModel model = (DefaultTableModel) workerJtable.getModel();
        model.setRowCount(0);
        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
            if (organization.getOrgType() != OrgType.WorkerOrg) {
                continue;
            }
            for (Employee employee : organization.getEmployeeDirectory().getEmployeeMap().values()) {
                Object[] row = new Object[1];
                row[0] = employee;
                model.addRow(row);
            }
        }
    }
 */
    
/////workerComboBox

    public void popWorkerComboBox() {
        workerCombo.removeAllItems();
 //       Enterprise enterprise = (Enterprise) enterpriseJComboBox.getSelectedItem();
/*
        for (UserAccount deliver : business.getOrganizationDirectory().getOrganizationList().get(2).getUserAccountDirectory().getUserAccountList()) {
            
            organizationJComboBox.addItem(deliver);
        }
*/

        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
            if (organization.getOrgType() != OrgType.WorkerOrg) {
                continue;
            }
            /*
            for (Employee employee : organization.getEmployeeDirectory().getEmployeeMap().values()) {
                workerCombo.addItem(employee);
            }
            */
            for (UserAccount ua : organization.getUserAccountDirectory().getUserAccountList()){
                workerCombo.addItem(ua);
            }       
    }
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titleJlabel = new javax.swing.JLabel();
        enterpriseJlabel = new javax.swing.JLabel();
        valueJlabel = new javax.swing.JLabel();
        orgJlabel = new javax.swing.JLabel();
        orgValueJlabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        workRequestJtable = new javax.swing.JTable();
        assignBtn = new javax.swing.JButton();
        markBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        workerCombo = new javax.swing.JComboBox<>();
        orgJlabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(153, 153, 153));

        titleJlabel.setFont(new java.awt.Font("Adobe Caslon Pro", 2, 48)); // NOI18N
        titleJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJlabel.setText("GenerateManager ");
        titleJlabel.setMaximumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setMinimumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setPreferredSize(new java.awt.Dimension(170, 30));

        enterpriseJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        enterpriseJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        enterpriseJlabel.setText("Enterprise:");
        enterpriseJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        valueJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        valueJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        valueJlabel.setText("value");
        valueJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        orgJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        orgJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orgJlabel.setText("Organization:");
        orgJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        orgJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        orgJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        orgValueJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        orgValueJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orgValueJlabel.setText("value");
        orgValueJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        orgValueJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        orgValueJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        workRequestJtable.setFont(new java.awt.Font("宋体", 0, 18)); // NOI18N
        workRequestJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product Request", "Cargo Name", "Receiver", "Require Time", "Cargo Quantity", "Message"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(workRequestJtable);

        assignBtn.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        assignBtn.setText("Assign Worker");
        assignBtn.setMaximumSize(new java.awt.Dimension(90, 30));
        assignBtn.setMinimumSize(new java.awt.Dimension(90, 30));
        assignBtn.setPreferredSize(new java.awt.Dimension(150, 30));
        assignBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignBtnActionPerformed(evt);
            }
        });

        markBtn.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        markBtn.setText("Mark as Finish");
        markBtn.setMaximumSize(new java.awt.Dimension(90, 30));
        markBtn.setMinimumSize(new java.awt.Dimension(90, 30));
        markBtn.setPreferredSize(new java.awt.Dimension(150, 30));
        markBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                markBtnActionPerformed(evt);
            }
        });

        workerCombo.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        workerCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        workerCombo.setPreferredSize(new java.awt.Dimension(90, 30));

        orgJlabel1.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        orgJlabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orgJlabel1.setText("Assign  a worker");
        orgJlabel1.setMaximumSize(new java.awt.Dimension(120, 30));
        orgJlabel1.setMinimumSize(new java.awt.Dimension(120, 30));
        orgJlabel1.setPreferredSize(new java.awt.Dimension(120, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(67, 67, 67)
                                        .addComponent(orgJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(84, 84, 84)
                                        .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(23, 23, 23)))
                                .addGap(149, 149, 149)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(orgValueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(orgJlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(assignBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(markBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 682, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(workerCombo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 682, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(665, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(orgValueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(orgJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(orgJlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(workerCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(markBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(295, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void assignBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignBtnActionPerformed
        int selectedRow = workRequestJtable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please at least select a Work Request row", "GET REQUEST", JOptionPane.ERROR_MESSAGE);
            return;
        }
        ProductRequest request = (ProductRequest) workRequestJtable.getValueAt(selectedRow, 0);
/*
        int selectedWorkerRow = workerJtable.getSelectedRow();
        if (selectedWorkerRow < 0) {
            JOptionPane.showMessageDialog(null, "Please at least select a Worker row", "GET REQUEST", JOptionPane.ERROR_MESSAGE);
            return;
        }
*/
        UserAccount ua = (UserAccount) workerCombo.getSelectedItem();
//        Employee employee = (Employee) workerJtable.getValueAt(selectedWorkerRow, 0);
//        Employee employee = (Employee) workerCombo.getSelectedItem();
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        userJpanel.add("GenerateRequestJpanel", new GenerateRequestJpanel(userJpanel, /*userAccount,*/ua, enterprise, /*employee,*/ request));
        layout.next(userJpanel);
    }//GEN-LAST:event_assignBtnActionPerformed

    private void markBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_markBtnActionPerformed
        int selectedRow = workRequestJtable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please at least select a Work Request row", "GET REQUEST", JOptionPane.ERROR_MESSAGE);
            return;
        }
        ProductRequest productRequest = (ProductRequest) workRequestJtable.getValueAt(selectedRow, 0);
        productRequest.setMessage("complete");
        populateRequestTable();
    }//GEN-LAST:event_markBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton assignBtn;
    private javax.swing.JLabel enterpriseJlabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton markBtn;
    private javax.swing.JLabel orgJlabel;
    private javax.swing.JLabel orgJlabel1;
    private javax.swing.JLabel orgValueJlabel;
    private javax.swing.JLabel titleJlabel;
    private javax.swing.JLabel valueJlabel;
    private javax.swing.JTable workRequestJtable;
    private javax.swing.JComboBox<Object> workerCombo;
    // End of variables declaration//GEN-END:variables
}
