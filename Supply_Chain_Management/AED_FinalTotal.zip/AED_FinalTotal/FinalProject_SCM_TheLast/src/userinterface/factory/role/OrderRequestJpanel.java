package userinterface.factory.role;

import business.SortByPrice;
import business.SortByQuantity;
import business.enterprise.Enterprise;
import business.enterprise.factory.Cargo;
import business.enterprise.factory.CargoDirectory;
import business.organization.Organization;
import business.organization.OrderMngOrg;
import business.organization.StoreMngOrg;
import business.useraccount.UserAccount;
import business.workqueue.OrderRequest;
import business.workqueue.WorkRequest;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lhm
 */
public class OrderRequestJpanel extends javax.swing.JPanel {

    private JPanel userJpanel;
    private UserAccount userAccount;
    private Enterprise enterprise;
    private CargoDirectory cargoDirectory;
    private ArrayList<Cargo>cargolist;
    public OrderRequestJpanel(JPanel userJpanel, UserAccount userAccount, Enterprise enterprise) {
        this.userJpanel = userJpanel;
        this.enterprise = enterprise;
        this.userAccount = userAccount;
        this.cargoDirectory = new CargoDirectory();
        initComponents();
        valueJlabel.setText(enterprise.getEnterpriseName());
        this.cargolist=cargoDirectory.getCargoList();
        jButton3.setToolTipText("<html>Make sure your head isn’t in the beam while trying to grab the Jordan 6 Retro Black Infrared (2019).<br> This AJ6 come with a black upper, black midsole plus red accents, and a translucent sole. <br>These sneakers released in February 2019 and retailed for $200<html>");
        jButton2.setToolTipText("<html>This AJ 1 features classic “Black Toe” color scheme.<br> This design is constructed in a mix of leather and satin construction providing a luxury feel.<br> A metal Wings logo on the heel completes the design. These sneakers released in August of 2019 and retailed for $160.<html>");
        jButton1.setToolTipText("<html>This Jordan 11 features a black upper with shiny patent leather overlays and red detailing. <br>A red translucent outsole, white midsole, and “23” insignia on the heel completes the design.<br> These sneakers released in November of 2019 and retailed for $220.<html>");
    }

    private void populateTable() {
        DefaultTableModel model = (DefaultTableModel) cargoJtable.getModel();
        model.setRowCount(0);
        for (Cargo cargo : cargoDirectory.getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }

     private void populateTable(Comparator<Cargo> aComparator) {
        DefaultTableModel model = (DefaultTableModel) cargoJtable.getModel();
        model.setRowCount(0);
        Collections.sort(cargolist, aComparator);
        for (Cargo cargo : cargoDirectory.getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    private boolean checkValid(String cargoName, String quantity, String price) {
        if (cargoName == null || cargoName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please input the Cargo Name", "ADD", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (quantity == null || quantity.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please input the Cargo Quantity", "ADD", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!isNumber(quantity)) {
            JOptionPane.showMessageDialog(null, "Please input the Cargo Quantity as digit", "ADD", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (Integer.parseInt(quantity) < 1) {
            JOptionPane.showMessageDialog(null, "The Cargo Quantity should larger than 0", "ADD", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!(price == null || price.isEmpty()) && !isNumber(price)) {
            JOptionPane.showMessageDialog(null, "The Price should be digit", "ADD", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean isNumber(String str) {
        String reg = "^[0-9]+(.[0-9]+)?$";
        return str.matches(reg);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        messageJlabel = new javax.swing.JLabel();
        submitJButton = new javax.swing.JButton();
        messageJtext = new javax.swing.JTextField();
        backJButton = new javax.swing.JButton();
        titleJlabel = new javax.swing.JLabel();
        valueJlabel = new javax.swing.JLabel();
        enterpriseJlabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cargoJtable = new javax.swing.JTable();
        addCargoBtn = new javax.swing.JButton();
        cargoNameJlabel = new javax.swing.JLabel();
        cargoNameJtext = new javax.swing.JTextField();
        quantityJlabel = new javax.swing.JLabel();
        quantityJtext = new javax.swing.JTextField();
        priceJlabel = new javax.swing.JLabel();
        priceJtext = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnSort = new javax.swing.JButton();
        jCBWayOfSort = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(153, 153, 153));

        messageJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        messageJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messageJlabel.setText("Request Message:");
        messageJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        messageJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        messageJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        submitJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        submitJButton.setText("Submit");
        submitJButton.setMaximumSize(new java.awt.Dimension(90, 30));
        submitJButton.setMinimumSize(new java.awt.Dimension(90, 30));
        submitJButton.setPreferredSize(new java.awt.Dimension(90, 30));
        submitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitJButtonActionPerformed(evt);
            }
        });

        messageJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        messageJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        messageJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        messageJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        messageJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        backJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        backJButton.setText("< Back");
        backJButton.setMaximumSize(new java.awt.Dimension(120, 30));
        backJButton.setMinimumSize(new java.awt.Dimension(120, 30));
        backJButton.setPreferredSize(new java.awt.Dimension(120, 30));
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });

        titleJlabel.setFont(new java.awt.Font("Times New Roman", 2, 48)); // NOI18N
        titleJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJlabel.setText("Order Request");
        titleJlabel.setMaximumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setMinimumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setPreferredSize(new java.awt.Dimension(170, 30));

        valueJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        valueJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        valueJlabel.setText("value");
        valueJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        valueJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        enterpriseJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        enterpriseJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        enterpriseJlabel.setText("Enterprise:");
        enterpriseJlabel.setMaximumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        enterpriseJlabel.setPreferredSize(new java.awt.Dimension(120, 30));

        cargoJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cargo Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(cargoJtable);

        addCargoBtn.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        addCargoBtn.setText("Add Cargo");
        addCargoBtn.setMaximumSize(new java.awt.Dimension(120, 30));
        addCargoBtn.setMinimumSize(new java.awt.Dimension(90, 30));
        addCargoBtn.setPreferredSize(new java.awt.Dimension(120, 30));
        addCargoBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCargoBtnActionPerformed(evt);
            }
        });

        cargoNameJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        cargoNameJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cargoNameJlabel.setText("Cargo Name:");
        cargoNameJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        cargoNameJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        cargoNameJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        cargoNameJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cargoNameJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        cargoNameJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        quantityJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        quantityJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        quantityJlabel.setText("Quantity:");
        quantityJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        quantityJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        quantityJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        quantityJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        quantityJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        quantityJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        quantityJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        quantityJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        priceJlabel.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        priceJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        priceJlabel.setText("Price:");
        priceJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        priceJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        priceJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        priceJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        priceJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        priceJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        priceJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        priceJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        btnSort.setText("Sort");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        jCBWayOfSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quantity", "Price" }));
        jCBWayOfSort.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jCBWayOfSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBWayOfSortActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/userinterface/factory/role/aj11_gaitubao_108x77.jpg"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/userinterface/factory/role/aj1_gaitubao_133x86.jpg"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/userinterface/factory/role/aj3_gaitubao_131x103.jpg"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Brush Script Std", 1, 24)); // NOI18N
        jLabel2.setText("Best Seller");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel1)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(108, 108, 108)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(cargoNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(quantityJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(43, 43, 43))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(priceJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(56, 56, 56)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(quantityJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cargoNameJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(priceJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(addCargoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(messageJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(337, 337, 337))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(130, 130, 130))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(151, 151, 151)
                                                .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGap(270, 270, 270)
                                                .addComponent(messageJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSort)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(valueJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(enterpriseJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(messageJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(messageJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSort)
                                    .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cargoNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cargoNameJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(quantityJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(quantityJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(priceJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(priceJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addCargoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabel2)))
                .addContainerGap(284, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void submitJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitJButtonActionPerformed
        String message = messageJtext.getText();
        if (message == null || message.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please input the request message", "SUBMIT", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (this.cargoDirectory.getCargoList().size() == 0) {
            JOptionPane.showMessageDialog(null, "Please at least input one kind of cargo", "SUBMIT", JOptionPane.ERROR_MESSAGE);
            return;
        }

        OrderRequest orderRequest = new OrderRequest(userAccount, message);
        orderRequest.getOrder().setCargoDirectory(this.cargoDirectory);
        ArrayList<Organization> orgList = new ArrayList<Organization>();
        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
            if (organization instanceof OrderMngOrg || organization instanceof StoreMngOrg) {
                orgList.add(organization);
            }
        }

        for (Organization organization : orgList) {
            organization.getWorkQueue().getWorkRequestList().add(orderRequest);
            for (UserAccount useraccount : organization.getUserAccountDirectory().getUserAccountList()) {
                useraccount.getWorkQueue().getWorkRequestList().add(orderRequest);
            }
        }
        
        messageJtext.setText("");
        this.cargoDirectory = new CargoDirectory();
        populateTable();
        JOptionPane.showMessageDialog(null, "Order Submit OK!", "SUMBIT", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_submitJButtonActionPerformed

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed
        userJpanel.remove(this);
        Component[] componentArray = userJpanel.getComponents();
        Component component = componentArray[componentArray.length - 1];
        OrderRoleInterface orderInterface = (OrderRoleInterface) component;
        orderInterface.populateRequestTable();
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        layout.previous(userJpanel);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void addCargoBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCargoBtnActionPerformed
        String cargoName = cargoNameJtext.getText();
        String quantityStr = quantityJtext.getText();
        String priceStr = priceJtext.getText();
        if (!checkValid(cargoName, quantityStr, priceStr)) {
            return;
        }

        Cargo cargo = new Cargo(cargoName);
        int price = (priceStr == null || priceStr.isEmpty()) ? 0 : Integer.parseInt(priceStr);
        cargo.setPrice(price);
        cargo.setQuantity(Integer.parseInt(quantityStr));
        this.cargoDirectory.getCargoList().add(cargo);
        populateTable();
    }//GEN-LAST:event_addCargoBtnActionPerformed

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        // TODO add your handling code here:
        String sortpattern = (String)jCBWayOfSort.getSelectedItem();
        switch(sortpattern){
            case "Quantity":
            SortByQuantity WayOfSortByAge = new SortByQuantity();
            populateTable(WayOfSortByAge);
            break;

            case "Price":
            SortByPrice WayOfSortByName = new SortByPrice();
            populateTable(WayOfSortByName);
            break;

        }
    }//GEN-LAST:event_btnSortActionPerformed

    private void jCBWayOfSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBWayOfSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCBWayOfSortActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        cargoNameJtext.setText("AJ11");
        priceJtext.setText("230");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        cargoNameJtext.setText("AJ1");
        priceJtext.setText("450");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        cargoNameJtext.setText("AJ6");
        priceJtext.setText("250");
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addCargoBtn;
    private javax.swing.JButton backJButton;
    private javax.swing.JButton btnSort;
    private javax.swing.JTable cargoJtable;
    private javax.swing.JLabel cargoNameJlabel;
    private javax.swing.JTextField cargoNameJtext;
    private javax.swing.JLabel enterpriseJlabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jCBWayOfSort;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel messageJlabel;
    private javax.swing.JTextField messageJtext;
    private javax.swing.JLabel priceJlabel;
    private javax.swing.JTextField priceJtext;
    private javax.swing.JLabel quantityJlabel;
    private javax.swing.JTextField quantityJtext;
    private javax.swing.JButton submitJButton;
    private javax.swing.JLabel titleJlabel;
    private javax.swing.JLabel valueJlabel;
    // End of variables declaration//GEN-END:variables
}
