package userinterface.factory.role;

import business.SortByPrice;
import business.SortByQuantity;
import business.enterprise.factory.Cargo;
import business.role.StoreManagerRole;
import business.useraccount.UserAccount;
import business.workqueue.OrderRequest;
import business.workqueue.WorkRequest;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lhm
 */
public class StoreMngJpanel extends javax.swing.JPanel {

    private JPanel userJpanel;
    private OrderRequest request;
    private UserAccount userAccount;
    private ArrayList<Cargo>cargolist;
    
    public StoreMngJpanel(JPanel userJpanel, OrderRequest request, UserAccount userAccount) {
        this.userJpanel = userJpanel;
        this.request = request;
        this.userAccount = userAccount;
        initComponents();
        populateTable();
        populateStoreTable();
        this.cargolist=request.getOrder().getCargoDirectory().getCargoList();
    }

    public void populateTable() {
        DefaultTableModel model = (DefaultTableModel) cargoJtable.getModel();
        model.setRowCount(0);
        for (Cargo cargo : request.getOrder().getCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }

     public void populateTable(Comparator<Cargo> aComparator) {
        DefaultTableModel model = (DefaultTableModel) cargoJtable.getModel();
        model.setRowCount(0);
        Collections.sort(cargolist, aComparator);
        for (Cargo cargo : request.getOrder().getCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    public void populateStoreTable(Comparator<Cargo> aComparator) {
        DefaultTableModel model = (DefaultTableModel) storeJtable.getModel();
        model.setRowCount(0);
       Collections.sort(cargolist, aComparator);
        for (Cargo cargo : ((StoreManagerRole)this.userAccount.getRole()).getStoreCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }

     public void populateStoreTable() {
        DefaultTableModel model = (DefaultTableModel) storeJtable.getModel();
        model.setRowCount(0);
        for (Cargo cargo : ((StoreManagerRole)this.userAccount.getRole()).getStoreCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        storeJtable = new javax.swing.JTable();
        backJButton = new javax.swing.JButton();
        titleJlabel = new javax.swing.JLabel();
        viewBtn = new javax.swing.JButton();
        addBtn = new javax.swing.JButton();
        cargoNameJlabel = new javax.swing.JLabel();
        cargoNameJtext = new javax.swing.JTextField();
        quantityJtext = new javax.swing.JTextField();
        quantityJlabel = new javax.swing.JLabel();
        priceJlabel = new javax.swing.JLabel();
        priceJtext = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        cargoJtable = new javax.swing.JTable();
        cargoNameJlabel1 = new javax.swing.JLabel();
        cargoNameJlabel2 = new javax.swing.JLabel();
        btnSort = new javax.swing.JButton();
        jCBWayOfSort = new javax.swing.JComboBox<>();

        setBackground(new java.awt.Color(153, 153, 153));

        storeJtable.setFont(new java.awt.Font("宋体", 0, 18)); // NOI18N
        storeJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cargo Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(storeJtable);

        backJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        backJButton.setText("< Back");
        backJButton.setMaximumSize(new java.awt.Dimension(120, 30));
        backJButton.setMinimumSize(new java.awt.Dimension(120, 30));
        backJButton.setPreferredSize(new java.awt.Dimension(120, 30));
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });

        titleJlabel.setFont(new java.awt.Font("Times New Roman", 2, 48)); // NOI18N
        titleJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJlabel.setText("Store Manage");
        titleJlabel.setMaximumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setMinimumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setPreferredSize(new java.awt.Dimension(170, 30));

        viewBtn.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        viewBtn.setText("View");
        viewBtn.setMaximumSize(new java.awt.Dimension(90, 30));
        viewBtn.setMinimumSize(new java.awt.Dimension(90, 30));
        viewBtn.setPreferredSize(new java.awt.Dimension(90, 30));
        viewBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewBtnActionPerformed(evt);
            }
        });

        addBtn.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        addBtn.setText("Add");
        addBtn.setMaximumSize(new java.awt.Dimension(90, 30));
        addBtn.setMinimumSize(new java.awt.Dimension(90, 30));
        addBtn.setPreferredSize(new java.awt.Dimension(90, 30));
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        cargoNameJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        cargoNameJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cargoNameJlabel.setText("Cargo Name:");
        cargoNameJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        cargoNameJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        cargoNameJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        cargoNameJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cargoNameJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        cargoNameJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        quantityJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        quantityJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        quantityJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        quantityJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        quantityJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        quantityJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        quantityJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        quantityJlabel.setText("Quantity:");
        quantityJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        quantityJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        quantityJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        priceJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        priceJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        priceJlabel.setText("Price:");
        priceJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        priceJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        priceJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        priceJtext.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        priceJtext.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        priceJtext.setMaximumSize(new java.awt.Dimension(120, 30));
        priceJtext.setMinimumSize(new java.awt.Dimension(120, 30));
        priceJtext.setPreferredSize(new java.awt.Dimension(120, 30));

        cargoJtable.setFont(new java.awt.Font("宋体", 0, 18)); // NOI18N
        cargoJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cargo Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(cargoJtable);

        cargoNameJlabel1.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        cargoNameJlabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cargoNameJlabel1.setText("Remain:");
        cargoNameJlabel1.setMaximumSize(new java.awt.Dimension(150, 30));
        cargoNameJlabel1.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJlabel1.setPreferredSize(new java.awt.Dimension(150, 30));

        cargoNameJlabel2.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        cargoNameJlabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cargoNameJlabel2.setText("Cargo Require:");
        cargoNameJlabel2.setMaximumSize(new java.awt.Dimension(150, 30));
        cargoNameJlabel2.setMinimumSize(new java.awt.Dimension(120, 30));
        cargoNameJlabel2.setPreferredSize(new java.awt.Dimension(150, 30));

        btnSort.setText("Sort");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        jCBWayOfSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quantity", "Price" }));
        jCBWayOfSort.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jCBWayOfSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBWayOfSortActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cargoNameJlabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(294, 294, 294)
                        .addComponent(btnSort)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(priceJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(quantityJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cargoNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(94, 94, 94)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(cargoNameJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(quantityJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(priceJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(viewBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(cargoNameJlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(638, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnSort)
                                .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cargoNameJlabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cargoNameJlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cargoNameJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cargoNameJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(quantityJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(quantityJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(priceJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3))
                            .addComponent(priceJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(viewBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(119, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed
        userJpanel.remove(this);
        Component[] componentArray = userJpanel.getComponents();
        Component component = componentArray[componentArray.length - 1];
        PurchasingAgentRoleInterface sellerInterface = (PurchasingAgentRoleInterface) component;
        sellerInterface.populateTable();
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        layout.previous(userJpanel);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void viewBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewBtnActionPerformed
        int selectedRow = storeJtable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please at least select a row", "VIEW", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Cargo cargo = (Cargo) storeJtable.getValueAt(selectedRow, 0);
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        userJpanel.add("CargoDetailJpanel", new CargoDetailJpanel(userJpanel, cargo));
        layout.next(userJpanel);
    }//GEN-LAST:event_viewBtnActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        String cargoName = cargoNameJtext.getText();
        String quantityStr = quantityJtext.getText();
        String priceStr = priceJtext.getText();
        if (cargoName == null || cargoName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please input the Cargo Name", "ADD", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Cargo cargo = new Cargo(cargoName);
        int quantity = (quantityStr == null || quantityStr.isEmpty()) ? 0 : Integer.parseInt(quantityStr);
        int price = (priceStr == null || priceStr.isEmpty()) ? 0 : Integer.parseInt(priceStr);
        cargo.setPrice(price);
        cargo.setQuantity(quantity);
        ((StoreManagerRole) this.userAccount.getRole()).getStoreCargoDirectory().getCargoList().add(cargo);
        populateStoreTable();
    }//GEN-LAST:event_addBtnActionPerformed

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        // TODO add your handling code here:
        String sortpattern = (String)jCBWayOfSort.getSelectedItem();
        switch(sortpattern){
            case "Quantity":
            SortByQuantity WayOfSortByAge = new SortByQuantity();
            populateTable(WayOfSortByAge);
            populateStoreTable(WayOfSortByAge);
            break;

            case "Price":
            SortByPrice WayOfSortByName = new SortByPrice();
            populateTable(WayOfSortByName);
            populateStoreTable(WayOfSortByName);
            break;

        }
    }//GEN-LAST:event_btnSortActionPerformed

    private void jCBWayOfSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBWayOfSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCBWayOfSortActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton backJButton;
    private javax.swing.JButton btnSort;
    private javax.swing.JTable cargoJtable;
    private javax.swing.JLabel cargoNameJlabel;
    private javax.swing.JLabel cargoNameJlabel1;
    private javax.swing.JLabel cargoNameJlabel2;
    private javax.swing.JTextField cargoNameJtext;
    private javax.swing.JComboBox<String> jCBWayOfSort;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel priceJlabel;
    private javax.swing.JTextField priceJtext;
    private javax.swing.JLabel quantityJlabel;
    private javax.swing.JTextField quantityJtext;
    private javax.swing.JTable storeJtable;
    private javax.swing.JLabel titleJlabel;
    private javax.swing.JButton viewBtn;
    // End of variables declaration//GEN-END:variables
}
