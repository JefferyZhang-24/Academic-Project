package userinterface.factory.role;

import business.SortByPrice;
import business.SortByQuantity;
import business.enterprise.Enterprise;
import business.enterprise.factory.Cargo;
import business.organization.Organization;
import business.organization.PurchasingAgentOrg;
import business.role.StoreManagerRole;
import business.useraccount.UserAccount;
import business.workqueue.OrderRequest;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lhm
 */
public class StoreMngProcessJPanel extends javax.swing.JPanel {

    private JPanel userJpanel;
    private OrderRequest request;
    private UserAccount userAccount;
    private Enterprise enterprise;
    private ArrayList<Cargo>cargolist;
    
    public StoreMngProcessJPanel(JPanel userJpanel, OrderRequest request, UserAccount userAccount, Enterprise enterprise) {
        this.userJpanel = userJpanel;
        this.request = request;
        this.userAccount = userAccount;
        this.enterprise = enterprise;
        initComponents();
        populateRequireTable();
        populateRemainTable();
        this.cargolist=request.getOrder().getCargoDirectory().getCargoList();
    }

    private void populateRequireTable() {
        DefaultTableModel model = (DefaultTableModel) requireJtable.getModel();
        model.setRowCount(0);
        for (Cargo cargo : request.getOrder().getCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    private void populateRequireTable(Comparator<Cargo> aComparator) {
        DefaultTableModel model = (DefaultTableModel) requireJtable.getModel();
        model.setRowCount(0);
        for (Cargo cargo : request.getOrder().getCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    
    private void populateRemainTable() {
        DefaultTableModel model = (DefaultTableModel) remainJtable.getModel();
        model.setRowCount(0);
        
        for (Cargo cargo : ((StoreManagerRole) userAccount.getRole()).getStoreCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }
    
    private void populateRemainTable(Comparator<Cargo> aComparator) {
        DefaultTableModel model = (DefaultTableModel) remainJtable.getModel();
        model.setRowCount(0);
        Collections.sort(cargolist, aComparator);
        for (Cargo cargo : ((StoreManagerRole) userAccount.getRole()).getStoreCargoDirectory().getCargoList()) {
            Object[] row = new Object[3];
            row[0] = cargo;
            row[1] = cargo.getQuantity();
            row[2] = cargo.getPrice();
            model.addRow(row);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backJButton = new javax.swing.JButton();
        titleJlabel = new javax.swing.JLabel();
        resultJlabel = new javax.swing.JLabel();
        submitJButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        requireJtable = new javax.swing.JTable();
        requireJlabel = new javax.swing.JLabel();
        remainJlabel = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        remainJtable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnSort = new javax.swing.JButton();
        jCBWayOfSort = new javax.swing.JComboBox<>();
        resultJtext = new javax.swing.JTextField();

        setBackground(new java.awt.Color(153, 153, 153));

        backJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        backJButton.setText("< Back");
        backJButton.setMaximumSize(new java.awt.Dimension(120, 30));
        backJButton.setMinimumSize(new java.awt.Dimension(120, 30));
        backJButton.setPreferredSize(new java.awt.Dimension(120, 30));
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });

        titleJlabel.setFont(new java.awt.Font("Adobe Caslon Pro", 2, 48)); // NOI18N
        titleJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJlabel.setText("Store Mng Process");
        titleJlabel.setMaximumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setMinimumSize(new java.awt.Dimension(170, 30));
        titleJlabel.setPreferredSize(new java.awt.Dimension(170, 30));

        resultJlabel.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        resultJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        resultJlabel.setText("Comment:");
        resultJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        resultJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        resultJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        submitJButton.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        submitJButton.setText("Submit");
        submitJButton.setMaximumSize(new java.awt.Dimension(90, 30));
        submitJButton.setMinimumSize(new java.awt.Dimension(90, 30));
        submitJButton.setPreferredSize(new java.awt.Dimension(90, 30));
        submitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitJButtonActionPerformed(evt);
            }
        });

        requireJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cargo Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(requireJtable);

        requireJlabel.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        requireJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        requireJlabel.setText("Require:");
        requireJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        requireJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        requireJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        remainJlabel.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        remainJlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        remainJlabel.setText("Remain:");
        remainJlabel.setMaximumSize(new java.awt.Dimension(150, 30));
        remainJlabel.setMinimumSize(new java.awt.Dimension(120, 30));
        remainJlabel.setPreferredSize(new java.awt.Dimension(150, 30));

        remainJtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cargo Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(remainJtable);

        btnSort.setText("Sort");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        jCBWayOfSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quantity", "Price" }));
        jCBWayOfSort.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jCBWayOfSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBWayOfSortActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(requireJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(16, 16, 16)
                                    .addComponent(resultJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(resultJtext, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnSort)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 687, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(remainJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(389, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(titleJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnSort)
                                .addComponent(jCBWayOfSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(requireJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(remainJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(resultJlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(resultJtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(submitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(147, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed
        userJpanel.remove(this);
        Component[] componentArray = userJpanel.getComponents();
        Component component = componentArray[componentArray.length - 1];
        StoreRoleInterface storeInterface = (StoreRoleInterface) component;
        storeInterface.populateRequestTable();
        CardLayout layout = (CardLayout) userJpanel.getLayout();
        layout.previous(userJpanel);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void submitJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitJButtonActionPerformed
        ArrayList<Organization> orgList = new ArrayList<Organization>();
        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
            if (organization instanceof PurchasingAgentOrg) {
                orgList.add(organization);
            }
        }
        for (Organization organization : orgList) {
            organization.getWorkQueue().getWorkRequestList().add(request);
            for (UserAccount useraccount : organization.getUserAccountDirectory().getUserAccountList()) {
                useraccount.getWorkQueue().getWorkRequestList().add(request);
            }
        }
        request.setResult(resultJtext.getText());
        request.setStatus("PurchasingAgent Processed...");
        JOptionPane.showMessageDialog(null, "StoreManage Organization processed!", "SUMBIT", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_submitJButtonActionPerformed

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        // TODO add your handling code here:
        String sortpattern = (String)jCBWayOfSort.getSelectedItem();
        switch(sortpattern){
            case "Quantity":
            SortByQuantity WayOfSortByAge = new SortByQuantity();
            populateRequireTable(WayOfSortByAge);
            populateRemainTable(WayOfSortByAge);
            break;

            case "Price":
            SortByPrice WayOfSortByName = new SortByPrice();
            populateRequireTable(WayOfSortByName);
            populateRemainTable(WayOfSortByName);
            break;

        }
    }//GEN-LAST:event_btnSortActionPerformed

    private void jCBWayOfSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBWayOfSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCBWayOfSortActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backJButton;
    private javax.swing.JButton btnSort;
    private javax.swing.JComboBox<String> jCBWayOfSort;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel remainJlabel;
    private javax.swing.JTable remainJtable;
    private javax.swing.JLabel requireJlabel;
    private javax.swing.JTable requireJtable;
    private javax.swing.JLabel resultJlabel;
    private javax.swing.JTextField resultJtext;
    private javax.swing.JButton submitJButton;
    private javax.swing.JLabel titleJlabel;
    // End of variables declaration//GEN-END:variables
}
