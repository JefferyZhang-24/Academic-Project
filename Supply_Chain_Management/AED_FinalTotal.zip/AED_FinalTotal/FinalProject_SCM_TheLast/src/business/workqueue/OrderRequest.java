package business.workqueue;

import business.enterprise.factory.Order;
import business.useraccount.UserAccount;

/**
 *
 * @author lhm
 */
public class OrderRequest extends WorkRequest {

    private Order order;
    private String result;
    private boolean isStoreProcess;
    private boolean isSellerProcess;
    private UserAccount purchasingAgentRecevier;

    public OrderRequest(UserAccount userAccount, String msg) {
        super(userAccount, msg);
        this.order = new Order(userAccount);
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public UserAccount getPurchasingAgentRecevier() {
        return purchasingAgentRecevier;
    }

    public void setPurchasingAgentRecevier(UserAccount purchasingAgentRecevier) {
        this.purchasingAgentRecevier = purchasingAgentRecevier;
    }

    public boolean isIsStoreProcess() {
        return isStoreProcess;
    }

    public void setIsStoreProcess(boolean isStoreProcess) {
        this.isStoreProcess = isStoreProcess;
    }

    public boolean isIsSellerProcess() {
        return isSellerProcess;
    }

    public void setIsSellerProcess(boolean isSellerProcess) {
        this.isSellerProcess = isSellerProcess;
    }

    @Override
    public String toString() {
        return this.order.toString();
    }
}
