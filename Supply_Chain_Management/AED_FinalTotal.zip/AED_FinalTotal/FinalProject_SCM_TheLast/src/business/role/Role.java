package business.role;

import javax.swing.JPanel;
import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.useraccount.UserAccount;

/**
 *
 * @author lhm
 */
public abstract class Role {

    private String roleType;
    private int enterpriseID;
    private int orgID;

    public enum RoleType {
        Admin("Admin"),
        FactoryAdmin("FactoryAdmin"),
        SupplierAdmin("SupplierAdmin"),
        OrderManager("OrderManager"),
        StoreManager("StoreManager"),
        Pucharser("Pucharser"),
        Accountant("Accountant"),
        WorkerManager("WorkerManager"),
        GenerateManager("GenerateManager"),
        LogisticsManager("LogisticsManager");

        private String value;

        private RoleType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public Role(String roleType, int orgID, int enterpriseID) {
        this.roleType = roleType;
        this.orgID = orgID;
        this.enterpriseID = enterpriseID;
    }

    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String roleType) {
        this.roleType = roleType;
    }

    public abstract JPanel createWorkArea(JPanel userProcessContainer,
            UserAccount account,
            Organization organization,
            Enterprise enterprise,
            EcoSystem business);

    @Override
    public String toString() {
        return this.roleType;
    }

}
