package business.role;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.useraccount.UserAccount;
import javax.swing.JPanel;
import userinterface.factory.role.OrderRoleInterface;

/**
 *
 * @author lhm
 */
public class OrderManagerRole extends Role {

    public OrderManagerRole(String roleType, int orgID, int enterpriseID) {
        super(roleType, orgID, enterpriseID);
    }

    @Override
    public JPanel createWorkArea(JPanel userJpanel, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new OrderRoleInterface(userJpanel, enterprise, organization, account);
    }
}
