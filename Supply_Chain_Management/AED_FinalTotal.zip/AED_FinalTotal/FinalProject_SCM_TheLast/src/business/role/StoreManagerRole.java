package business.role;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.enterprise.factory.CargoDirectory;
import business.organization.Organization;
import business.useraccount.UserAccount;
import javax.swing.JPanel;
import userinterface.factory.role.StoreRoleInterface;

/**
 *
 * @author lhm
 */
public class StoreManagerRole extends Role {

    private CargoDirectory storeCargoDirectory;

    public StoreManagerRole(String roleType, int orgID, int enterpriseID) {
        super(roleType, orgID, enterpriseID);
        this.storeCargoDirectory = new CargoDirectory();
    }

    public CargoDirectory getStoreCargoDirectory() {
        return storeCargoDirectory;
    }

    public void setStoreCargoDirectory(CargoDirectory storeCargoDirectory) {
        this.storeCargoDirectory = storeCargoDirectory;
    }

    @Override
    public JPanel createWorkArea(JPanel userJpanel, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new StoreRoleInterface(userJpanel, enterprise, organization, account);
    }
}
