package business.role;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.useraccount.UserAccount;
import userinterface.factory.FactoryWorkAreaInterface;
import javax.swing.JPanel;

/**
 *
 * @author lhm
 */
public class FactoryAdminRole extends Role{

    public FactoryAdminRole(String roleType, int orgID, int enterpriseID) {
        super(roleType, orgID, enterpriseID);
    }

    @Override
    public JPanel createWorkArea(JPanel userJpanel, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new FactoryWorkAreaInterface(userJpanel, enterprise, business);
    }
    
}
