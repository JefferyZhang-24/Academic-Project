package business.role;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.useraccount.UserAccount;
import javax.swing.JPanel;
import userinterface.supplier.role.WorkerRoleInterface;

/**
 *
 * @author lhm
 */
public class WorkerRole extends Role {

    public WorkerRole(String roleType, int orgID, int enterpriseID){
        super(roleType, orgID, enterpriseID);
    }
    
    @Override
    public JPanel createWorkArea(JPanel userJpanel, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new WorkerRoleInterface(userJpanel, account);
    }
    
}
