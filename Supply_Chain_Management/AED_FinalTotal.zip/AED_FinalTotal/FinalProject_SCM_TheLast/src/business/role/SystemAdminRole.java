package business.role;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.useraccount.UserAccount;
import userinterface.systemadmin.SystemAdminInterface;

import javax.swing.JPanel;

/**
 *
 * @author lhm
 */
public class SystemAdminRole extends Role{

    public SystemAdminRole(String roleType, int orgID, int enterpriseID) {
        super(roleType, orgID, enterpriseID);
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem system) {
        return new SystemAdminInterface(userProcessContainer, system);
    }
    
}
