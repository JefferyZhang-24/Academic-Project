package business.enterprise.supplier;

import business.enterprise.Enterprise;
import business.organization.Organization;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class SupplierEnterprise extends Enterprise {
    public SupplierEnterprise(String name, int enterpriseID){
        super(name, Enterprise.EnterpriseType.Supplier, enterpriseID);
    }

    @Override
    public ArrayList<Organization.OrgType> getSupportedOrganization() {
        return new ArrayList<Organization.OrgType>() {
            {
                add(Organization.OrgType.GenerateOrg);
                add(Organization.OrgType.WorkerOrg);
                add(Organization.OrgType.LogisticsOrg);
            }
        };
    }

}
