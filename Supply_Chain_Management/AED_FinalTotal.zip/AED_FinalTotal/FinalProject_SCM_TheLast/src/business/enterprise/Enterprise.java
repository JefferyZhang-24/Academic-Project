package business.enterprise;

import business.employee.EmployeeDirectory;
import business.organization.OrganizationDirectory;
import business.organization.Organization;
import business.useraccount.UserAccountDirectory;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public abstract class Enterprise {

    private String enterpriseName;
    private int enterpriseID;
    private UserAccountDirectory userAccountDirectory;
    private EmployeeDirectory employeeDirectory;
    private OrganizationDirectory organizationDirectory;
    private EnterpriseType enterpriseType;

    public enum EnterpriseType {
        Factory("Factory Enterprise"), Supplier("Supplier Enterprise");
        private String value;
        private EnterpriseType(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Enterprise(String name, EnterpriseType type, int enterpriseID) {
        this.enterpriseName = name;
        this.enterpriseType = type;
        this.enterpriseID = enterpriseID;
        organizationDirectory = new OrganizationDirectory();
        userAccountDirectory = new UserAccountDirectory();
        employeeDirectory = new EmployeeDirectory();
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public int getEnterpriseID() {
        return enterpriseID;
    }

    public void setEnterpriseID(int enterpriseID) {
        this.enterpriseID = enterpriseID;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public void setEmployeeDirectory(EmployeeDirectory employeeDirectory) {
        this.employeeDirectory = employeeDirectory;
    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    public EnterpriseType getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(EnterpriseType enterpriseType) {
        this.enterpriseType = enterpriseType;
    }
    
    public abstract ArrayList<Organization.OrgType> getSupportedOrganization();

    @Override
    public String toString(){
        return this.enterpriseName + " (" + this.enterpriseType + ")";
    }

}
