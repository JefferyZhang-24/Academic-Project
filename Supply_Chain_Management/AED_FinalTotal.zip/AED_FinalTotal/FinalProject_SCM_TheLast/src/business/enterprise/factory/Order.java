package business.enterprise.factory;

import business.useraccount.UserAccount;
import java.util.Date;

/**
 *
 * @author lhm
 */
public class Order {

    private int orderID;
    private Date startTime;
    private Date requireTime;
    private UserAccount creator;
    private CargoDirectory cargoDirectory;
    private static int counter = 0;

    public Order(UserAccount creator) {
        this.creator = creator;
        this.cargoDirectory = new CargoDirectory();
        this.orderID = ++counter;
        this.startTime = new Date();
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getRequireTime() {
        return requireTime;
    }

    public void setRequireTime(Date requireTime) {
        this.requireTime = requireTime;
    }

    public UserAccount getCreator() {
        return creator;
    }

    public void setCreator(UserAccount creator) {
        this.creator = creator;
    }

    public CargoDirectory getCargoDirectory() {
        return cargoDirectory;
    }

    public void setCargoDirectory(CargoDirectory cargoDirectory) {
        this.cargoDirectory = cargoDirectory;
    }

    @Override
    public String toString() {
        return this.orderID + "(" + this.creator + ")";
    }
}
