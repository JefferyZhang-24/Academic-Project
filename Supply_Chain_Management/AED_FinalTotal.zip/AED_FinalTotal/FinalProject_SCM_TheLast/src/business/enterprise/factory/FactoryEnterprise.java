package business.enterprise.factory;

import business.enterprise.Enterprise;
import business.organization.Organization;
import business.organization.Organization.OrgType;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class FactoryEnterprise extends Enterprise {

    public FactoryEnterprise(String name, int enterpriseID) {
        super(name, EnterpriseType.Factory, enterpriseID);
    }

    @Override
    public ArrayList<Organization.OrgType> getSupportedOrganization() {
        return new ArrayList<Organization.OrgType>() {
            {
                add(OrgType.FinancialOrg);
                add(OrgType.OrderOrg);
                add(OrgType.PurchasingAgent);
                add(OrgType.StoreOrg);
            }
        };
    }

}
