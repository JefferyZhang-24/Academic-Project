package business.enterprise.factory;

import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class CargoDirectory {
    
    private ArrayList<Cargo> cargoList;
    
    public CargoDirectory(){
        this.cargoList = new ArrayList<Cargo> ();
    }

    public ArrayList<Cargo> getCargoList() {
        return cargoList;
    }

    public void setCargoList(ArrayList<Cargo> cargoList) {
        this.cargoList = cargoList;
    }
    
}
