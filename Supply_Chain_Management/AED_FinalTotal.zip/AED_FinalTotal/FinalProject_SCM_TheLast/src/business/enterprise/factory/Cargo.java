package business.enterprise.factory;

/**
 *
 * @author lhm
 */
public class Cargo {

    private String cargoName;
    private int quantity;
    private int price;

    public Cargo(String name) {
        this.cargoName = name;
    }

    public String getCargoName() {
        return cargoName;
    }

    public void setCargoName(String cargoName) {
        this.cargoName = cargoName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return this.cargoName;
    }
}
