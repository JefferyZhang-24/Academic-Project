package business.enterprise;

import business.enterprise.factory.FactoryEnterprise;
import business.enterprise.supplier.SupplierEnterprise;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class EnterpriseDirectory {

    private ArrayList<Enterprise> enterpriseList;
    private int num;

    public ArrayList<Enterprise> getEnterpriseList() {
        return enterpriseList;
    }

    public void setEnterpriseList(ArrayList<Enterprise> enterpriseList) {
        this.enterpriseList = enterpriseList;
    }

    public EnterpriseDirectory() {
        enterpriseList = new ArrayList<Enterprise>();
    }

    public Enterprise addEnterprise(String name, Enterprise.EnterpriseType type) {
        int num = this.enterpriseList.size();
        Enterprise enterprise = null;
        if (type == Enterprise.EnterpriseType.Factory) {
            enterprise = new FactoryEnterprise(name, num + 1);
            enterpriseList.add(enterprise);
        }
        if (type == Enterprise.EnterpriseType.Supplier) {
            enterprise = new SupplierEnterprise(name, num + 1);
            enterpriseList.add(enterprise);
        }
        this.num = this.enterpriseList.size();
        return enterprise;
    }
    
    public void deleteEnterprise(Enterprise enterprise){
        this.enterpriseList.remove(enterprise);
    }
}
