package business.organization;

import business.employee.EmployeeDirectory;
import business.role.Role;
import business.useraccount.UserAccountDirectory;
import business.workqueue.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public abstract class Organization {

    private int organizationID;
    private String name;
    private OrgType orgType;
    private String description;
    private int enterpriseID;
    private EmployeeDirectory employeeDirectory;
    private UserAccountDirectory userAccountDirectory;
    private WorkQueue workQueue;

    public enum OrgType {
        FactoryAdminOrg("FactoryAdmin Org"), PurchasingAgent("PurchasingAgent Org"), StoreOrg("StoreManage Org"),
        SupplierAdminOrg("SupplierAdmin Org"), OrderOrg("Order Org"), FinancialOrg("Financial Org"),
        GenerateOrg("Generate Org"), WorkerOrg("Worker Org"), SystemOrg("System Org"), LogisticsOrg("Logistics Org");

        private String value;

        private OrgType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public Organization(String name, OrgType orgType, int enterpriseID, int orgID) {
        this.name = name;
        this.orgType = orgType;
        this.enterpriseID = enterpriseID;
        employeeDirectory = new EmployeeDirectory();
        userAccountDirectory = new UserAccountDirectory();
        workQueue = new WorkQueue();
        organizationID = orgID;
    }

    public abstract ArrayList<Role> getSupportedRole();

    public int getOrganizationID() {
        return organizationID;
    }

    public void setOrganizationID(int organizationID) {
        this.organizationID = organizationID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public OrgType getOrgType() {
        return orgType;
    }

    public void setOrgType(OrgType orgType) {
        this.orgType = orgType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getEnterpriseID() {
        return enterpriseID;
    }

    public void setEnterpriseID(int enterpriseID) {
        this.enterpriseID = enterpriseID;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public void setEmployeeDirectory(EmployeeDirectory employeeDirectory) {
        this.employeeDirectory = employeeDirectory;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }



    @Override
    public String toString() {
        return this.name + " (" + this.organizationID + ")";
    }

}
