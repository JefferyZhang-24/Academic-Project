package business.organization;

import java.util.ArrayList;
import business.organization.Organization.OrgType;

/**
 *
 * @author lhm
 */
public class OrganizationDirectory {

    private ArrayList<Organization> organizationList;
    private int num;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }

    public Organization createOrganization(OrgType type, int enterpriseID) {
        Organization organization = null;
        int orgID = this.organizationList.size();
        if (type.getValue().equals(OrgType.FactoryAdminOrg.getValue())) {
            organization = new FactoryAdminOrg(OrgType.FactoryAdminOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.SupplierAdminOrg.getValue())) {
            organization = new SupplierAdminOrg(OrgType.SupplierAdminOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.PurchasingAgent.getValue())) {
            organization = new PurchasingAgentOrg(OrgType.PurchasingAgent, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.StoreOrg.getValue())) {
            organization = new StoreMngOrg(OrgType.StoreOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.OrderOrg.getValue())) {
            organization = new OrderMngOrg(OrgType.OrderOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.FinancialOrg.getValue())) {
            organization = new FinancialOrg(OrgType.FinancialOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.GenerateOrg.getValue())) {
            organization = new GenerateOrg(OrgType.GenerateOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.WorkerOrg.getValue())) {
            organization = new WorkerMngOrg(OrgType.WorkerOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.SystemOrg.getValue())) {
            organization = new SystemOrg(OrgType.SystemOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        } else if (type.getValue().equals(OrgType.LogisticsOrg.getValue())) {
            organization = new LogisticsOrg(OrgType.LogisticsOrg, enterpriseID, orgID+1);
            organizationList.add(organization);
        }
        this.num = this.organizationList.size();
        return organization;
    }
}
