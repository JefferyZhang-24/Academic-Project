package business.organization;

import business.role.AccountantRole;
import business.role.Role;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class FinancialOrg extends Organization {

    public FinancialOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        return new ArrayList<Role>() {
            {
                add(new AccountantRole(Role.RoleType.Accountant.getValue(), orgID, enterpriseID));
            }
        };
    }
}
