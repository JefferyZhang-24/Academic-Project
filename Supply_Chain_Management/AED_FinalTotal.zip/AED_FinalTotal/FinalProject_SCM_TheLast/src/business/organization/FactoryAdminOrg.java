package business.organization;

import business.role.FactoryAdminRole;
import business.role.Role;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class FactoryAdminOrg extends Organization {

    public FactoryAdminOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        
        return new ArrayList<Role>() {
            {
                add(new FactoryAdminRole(Role.RoleType.FactoryAdmin.getValue(), orgID, enterpriseID));
            }
        };
    }

}
