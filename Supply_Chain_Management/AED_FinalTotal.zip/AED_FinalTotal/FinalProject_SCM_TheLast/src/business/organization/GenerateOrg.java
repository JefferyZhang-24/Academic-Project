package business.organization;

import business.role.Role;
import business.role.GenerateManagerRole;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class GenerateOrg extends Organization {

    public GenerateOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        return new ArrayList<Role>() {
            {
                add(new GenerateManagerRole(Role.RoleType.GenerateManager.getValue(), orgID, enterpriseID));
            }
        };
    }

}
