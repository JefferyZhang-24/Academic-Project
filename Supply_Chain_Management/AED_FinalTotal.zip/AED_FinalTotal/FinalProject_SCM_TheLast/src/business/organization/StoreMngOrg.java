package business.organization;

import business.role.Role;
import business.role.StoreManagerRole;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class StoreMngOrg extends Organization {

    public StoreMngOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        
        return new ArrayList<Role>() {
            {
                add(new StoreManagerRole(Role.RoleType.StoreManager.getValue(), orgID, enterpriseID));
            }
        };
    }

}
