package business.organization;

import business.role.FactoryAdminRole;
import business.role.Role;
import business.role.SupplierAdminRole;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class SupplierAdminOrg extends Organization {

    public SupplierAdminOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        
        return new ArrayList<Role>() {
            {
                add(new SupplierAdminRole(Role.RoleType.SupplierAdmin.getValue(), orgID, enterpriseID));
            }
        };
    }

}
