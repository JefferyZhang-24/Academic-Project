package business.organization;

import business.role.OrderManagerRole;
import business.role.Role;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class OrderMngOrg extends Organization {

    public OrderMngOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();

        return new ArrayList<Role>() {
            {
                add(new OrderManagerRole(Role.RoleType.OrderManager.getValue(), orgID, enterpriseID));
            }
        };
    }

}
