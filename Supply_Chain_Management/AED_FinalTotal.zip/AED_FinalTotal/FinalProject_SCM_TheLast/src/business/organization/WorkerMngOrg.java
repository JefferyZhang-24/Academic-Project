package business.organization;

import business.role.Role;
import business.role.WorkerRole;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class WorkerMngOrg extends Organization {

    public WorkerMngOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        return new ArrayList<Role>() {
            {
                add(new WorkerRole(Role.RoleType.WorkerManager.getValue(), orgID, enterpriseID));
            }
        };
    }
}
