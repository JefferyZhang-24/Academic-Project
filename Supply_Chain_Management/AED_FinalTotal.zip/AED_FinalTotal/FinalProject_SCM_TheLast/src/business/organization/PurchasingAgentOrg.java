package business.organization;

import business.role.Role;
import business.role.PurchasingAgent;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class PurchasingAgentOrg extends Organization {

    public PurchasingAgentOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
         return new ArrayList<Role>() {
            {
                add(new PurchasingAgent(Role.RoleType.Pucharser.getValue(), orgID, enterpriseID));
            }
        };
    }
}
