package business.organization;

import business.role.LogisticsManagerRole;
import business.role.Role;
import java.util.ArrayList;

/**
 *
 * @author lhm
 */
public class LogisticsOrg extends Organization {

    public LogisticsOrg(OrgType orgType, int enterpriseID, int orgID) {
        super(orgType.getValue(), orgType, enterpriseID, orgID);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        int orgID = this.getOrganizationID();
        int enterpriseID = this.getEnterpriseID();
        return new ArrayList<Role>() {
            {
                add(new LogisticsManagerRole(Role.RoleType.LogisticsManager.getValue(), orgID, enterpriseID));
            }
        };
    }

}
