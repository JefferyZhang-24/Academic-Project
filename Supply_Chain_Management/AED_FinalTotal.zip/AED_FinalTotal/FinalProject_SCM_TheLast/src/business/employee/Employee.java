package business.employee;

import business.organization.Organization;
import business.organization.Organization.OrgType;
import business.useraccount.UserAccountDirectory;
import java.util.Date;

/**
 *
 * @author lhm
 */
public class Employee {

    private String name;
    private OrgType orgType;
    private int id;
    private int age;
    private String sex;
    private String location;
    private Date registerTime;
    private Date leaveTime;
    private int level;
    private double salary;
    private static int count = 0;
    
    private UserAccountDirectory userAccountDirectory;


    public Employee(String name, OrgType org) {
        this.name = name;
        this.orgType = org;
        if (orgType == OrgType.FinancialOrg) {
            this.salary = 1000;
        }
        if (orgType == OrgType.GenerateOrg) {
            this.salary = 1200;
        }
        if (orgType == OrgType.OrderOrg) {
            this.salary = 1300;
        }
        if (orgType == OrgType.FactoryAdminOrg) {
            this.salary = 1500;
        }
        if (orgType == OrgType.PurchasingAgent) {
            this.salary = 1800;
        }
        if (orgType == OrgType.StoreOrg) {
            this.salary = 1900;
        }
        if (orgType == OrgType.SupplierAdminOrg) {
            this.salary = 2000;
        }
        if (orgType == OrgType.WorkerOrg) {
            this.salary = 2100;
        }
        if (orgType == OrgType.LogisticsOrg) {
            this.salary = 2100;
        }        
        
        this.registerTime = new Date();
        id = ++count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public OrgType getOrgType() {
        return orgType;
    }

    public void setOrgType(OrgType orgType) {
        this.orgType = orgType;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Date getLeaveTime() {
        return leaveTime;
    }

    public void setLeaveTime(Date leaveTime) {
        this.leaveTime = leaveTime;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Employee.count = count;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }    
    
    @Override
    public String toString() {
        return this.name + " " + this.orgType;
    }
}
