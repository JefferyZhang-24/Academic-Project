package business.employee;

import business.organization.Organization;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author lhm
 */
public class EmployeeDirectory {
    private Map<Integer, Employee> employeeMap;

    public EmployeeDirectory() {
        employeeMap = new HashMap();
    }

    public Map<Integer, Employee> getEmployeeMap() {
        return employeeMap;
    }
    
    public Employee createEmployee(String name, Organization.OrgType orgType){
        Employee employee = new Employee(name, orgType);
        employeeMap.put(employee.getId(), employee);
        return employee;
    }
}
