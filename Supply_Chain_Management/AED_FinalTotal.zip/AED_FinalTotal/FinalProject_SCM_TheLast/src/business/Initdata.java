package business;

import business.employee.Employee;
import business.enterprise.Enterprise;
import business.network.Network;
import business.organization.Organization;
import business.role.AccountantRole;
import business.role.FactoryAdminRole;
import business.role.GenerateManagerRole;
import business.role.OrderManagerRole;
import business.role.PurchasingAgent;
import business.role.Role;
import business.role.StoreManagerRole;
import business.role.SupplierAdminRole;
import business.role.SystemAdminRole;
import business.role.WorkerRole;
import business.useraccount.UserAccount;
import business.role.LogisticsManagerRole;

/**
 *
 * @author lhm
 */
public class Initdata {

    public static EcoSystem configure() {

        EcoSystem system = EcoSystem.getInstance();

       // add some Basic examples
        Network networkBoston = system.getNetworkDirectory().createNetwork("Boston");
        System.out.println(networkBoston.getId());
        Network networkLA = system.getNetworkDirectory().createNetwork("LA");

        Enterprise enterpriseFactory1 = networkBoston.getEnterpriseDirectory().addEnterprise("Factory 1 Enterprise", Enterprise.EnterpriseType.Factory);
        Enterprise enterpriseFactory2 = networkLA.getEnterpriseDirectory().addEnterprise("Factory 2 Enterprise", Enterprise.EnterpriseType.Factory);
        Enterprise enterpriseSupplier1 = networkBoston.getEnterpriseDirectory().addEnterprise("Supplier 1 Enterprise", Enterprise.EnterpriseType.Supplier);
        Enterprise enterpriseSupplier2 = networkLA.getEnterpriseDirectory().addEnterprise("Supplier 2 Enterprise", Enterprise.EnterpriseType.Supplier);

        Organization orgFactoryAdminOrg = enterpriseFactory1.getOrganizationDirectory().createOrganization(Organization.OrgType.FactoryAdminOrg, 100);
        orgFactoryAdminOrg.setName("Factory 1");
        Organization orgOrderOrg = enterpriseFactory1.getOrganizationDirectory().createOrganization(Organization.OrgType.OrderOrg, 101);
        orgOrderOrg.setName("Order 1");
        Organization orgStoreOrg = enterpriseFactory1.getOrganizationDirectory().createOrganization(Organization.OrgType.StoreOrg, 102);
        orgStoreOrg.setName("Store 1");
        Organization orgPurchasingAgent = enterpriseFactory1.getOrganizationDirectory().createOrganization(Organization.OrgType.PurchasingAgent, 103);
        orgPurchasingAgent.setName("Purchase 1");
        Organization orgFinancialOrg = enterpriseFactory1.getOrganizationDirectory().createOrganization(Organization.OrgType.FinancialOrg, 104);
        orgFinancialOrg.setName("Financial 1");
        Organization orgSupplierAdminOrg = enterpriseSupplier1.getOrganizationDirectory().createOrganization(Organization.OrgType.SupplierAdminOrg, 105);
        orgSupplierAdminOrg.setName("Suppiler 1");
        Organization orgGenerateOrg = enterpriseSupplier1.getOrganizationDirectory().createOrganization(Organization.OrgType.GenerateOrg, 106);
        orgGenerateOrg.setName("Generate 1");
        Organization orgWorkerOrg = enterpriseSupplier1.getOrganizationDirectory().createOrganization(Organization.OrgType.WorkerOrg, 107);
        orgWorkerOrg.setName("Work 1");
        Organization orgLogisticsOrg = enterpriseSupplier1.getOrganizationDirectory().createOrganization(Organization.OrgType.LogisticsOrg, 108);
        orgWorkerOrg.setName("Logisctics 1");

        Role roleFactoryAdmin = new FactoryAdminRole(Role.RoleType.FactoryAdmin.getValue(), orgFactoryAdminOrg.getOrganizationID(), orgFactoryAdminOrg.getEnterpriseID());
        Role roleOrderManager = new OrderManagerRole(Role.RoleType.OrderManager.getValue(), orgOrderOrg.getOrganizationID(), orgOrderOrg.getEnterpriseID());
        Role roleStoreManager = new StoreManagerRole(Role.RoleType.StoreManager.getValue(), orgStoreOrg.getOrganizationID(), orgStoreOrg.getEnterpriseID());
        Role rolePucharser = new PurchasingAgent(Role.RoleType.Pucharser.getValue(), orgPurchasingAgent.getOrganizationID(), orgPurchasingAgent.getEnterpriseID());
        Role roleAccountant = new AccountantRole(Role.RoleType.Accountant.getValue(), orgFinancialOrg.getOrganizationID(), orgFinancialOrg.getEnterpriseID());
        Role roleSupplierAdmin = new SupplierAdminRole(Role.RoleType.SupplierAdmin.getValue(), orgSupplierAdminOrg.getOrganizationID(), orgSupplierAdminOrg.getEnterpriseID());
        Role roleGenerateManager = new GenerateManagerRole(Role.RoleType.GenerateManager.getValue(), orgGenerateOrg.getOrganizationID(), orgGenerateOrg.getEnterpriseID());
        Role roleWorkerManager = new WorkerRole(Role.RoleType.WorkerManager.getValue(), orgWorkerOrg.getOrganizationID(), orgWorkerOrg.getEnterpriseID());

        Employee employeeFactoryAdmin = orgFactoryAdminOrg.getEmployeeDirectory().createEmployee("factoryadmin", Organization.OrgType.FactoryAdminOrg);
        Employee employeeOrder = orgOrderOrg.getEmployeeDirectory().createEmployee("order", Organization.OrgType.OrderOrg);
        Employee employeeStore = orgStoreOrg.getEmployeeDirectory().createEmployee("store", Organization.OrgType.StoreOrg);
        Employee employeePurchase = orgPurchasingAgent.getEmployeeDirectory().createEmployee("purchase", Organization.OrgType.PurchasingAgent);
        Employee employeeAccountant = orgFinancialOrg.getEmployeeDirectory().createEmployee("accountant", Organization.OrgType.FinancialOrg);
        Employee employeeSupplierAdmin = orgSupplierAdminOrg.getEmployeeDirectory().createEmployee("supplieradmin", Organization.OrgType.SupplierAdminOrg);
        Employee employeeGenerator = orgGenerateOrg.getEmployeeDirectory().createEmployee("generator", Organization.OrgType.GenerateOrg);
        Employee employeeWorker = orgWorkerOrg.getEmployeeDirectory().createEmployee("worker", Organization.OrgType.WorkerOrg);

        UserAccount userFactoryAdmin = orgFactoryAdminOrg.getUserAccountDirectory().createUserAccount("factoryadmin", "lux123", employeeFactoryAdmin, roleFactoryAdmin, orgFactoryAdminOrg);
        enterpriseFactory1.getUserAccountDirectory().createUserAccount("factoryadmin", "lux123", employeeFactoryAdmin, roleFactoryAdmin, orgFactoryAdminOrg);
        UserAccount userOrder = orgOrderOrg.getUserAccountDirectory().createUserAccount("order", "lux123", employeeOrder, roleOrderManager, orgOrderOrg);
        UserAccount userStore = orgStoreOrg.getUserAccountDirectory().createUserAccount("store", "lux123", employeeStore, roleStoreManager, orgStoreOrg);
        UserAccount userPurchase = orgPurchasingAgent.getUserAccountDirectory().createUserAccount("purchase", "lux123", employeePurchase, rolePucharser, orgPurchasingAgent);
        UserAccount userFinancial = orgFinancialOrg.getUserAccountDirectory().createUserAccount("financial", "lux123", employeeAccountant, roleAccountant, orgFinancialOrg);
        UserAccount userSupplieradmin = orgSupplierAdminOrg.getUserAccountDirectory().createUserAccount("supplieradmin", "lux123", employeeSupplierAdmin, roleSupplierAdmin, orgSupplierAdminOrg);
        enterpriseFactory2.getUserAccountDirectory().createUserAccount("supplieradmin", "lux123", employeeSupplierAdmin, roleSupplierAdmin, orgSupplierAdminOrg);
        UserAccount userGenerator = orgGenerateOrg.getUserAccountDirectory().createUserAccount("generator", "lux123", employeeGenerator, roleGenerateManager, orgGenerateOrg);
        UserAccount userWorker = orgWorkerOrg.getUserAccountDirectory().createUserAccount("generator", "lux123", employeeGenerator, roleGenerateManager, orgWorkerOrg);
        UserAccount userLogistics = orgLogisticsOrg.getUserAccountDirectory().createUserAccount("Logistics", "lux123", employeeGenerator, roleGenerateManager, orgLogisticsOrg);

        Employee employeeSystem = system.getEmployeeDirectory().createEmployee("sysadmin", Organization.OrgType.SystemOrg);
        Organization orgSystem = system.getOrganizationDirectory().createOrganization(Organization.OrgType.SystemOrg, 0);
        UserAccount ua = system.getUserAccountDirectory().createUserAccount(
                "sysadmin", "sysadmin", employeeSystem, new SystemAdminRole(Role.RoleType.Admin.getValue(), 0, 0), orgSystem);
        return system;
    }
}
