/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.employee.Employee;
import java.util.Comparator;
import java.util.Map;

/**
 *
 * @author Kiksuya
 */
public class SortBySalary implements Comparator<Map.Entry<Integer, Employee>>{
     public SortBySalary() {
        super();
    }
    @Override
    public int compare(Map.Entry<Integer, Employee> o1, Map.Entry<Integer, Employee> o2) {
          return (int) (o1.getValue().getSalary()-o2.getValue().getSalary());
    }
}
