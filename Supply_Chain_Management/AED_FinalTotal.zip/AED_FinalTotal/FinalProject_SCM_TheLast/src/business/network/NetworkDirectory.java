package business.network;

import java.util.ArrayList;
import java.util.Map;

/**
 *
 * @author lhm
 */
public class NetworkDirectory {

    private ArrayList<Network> networkList;

    public NetworkDirectory() {
        networkList = new ArrayList<Network>();
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    public Network createNetwork(String name) {
        Network network = new Network(name);
        networkList.add(network);
        return network;
    }

    public void deleteNetwork(Network network) {
        this.networkList.remove(network);
    }
}
