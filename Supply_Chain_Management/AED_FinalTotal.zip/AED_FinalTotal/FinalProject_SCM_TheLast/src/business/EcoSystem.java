package business;

import business.employee.EmployeeDirectory;
import business.enterprise.Enterprise;
import business.network.Network;
import business.network.NetworkDirectory;
import business.organization.Organization;
import business.organization.OrganizationDirectory;
import business.useraccount.UserAccountDirectory;

/**
 *
 * @author lhm
 */
public class EcoSystem {

    private static EcoSystem business;
    private NetworkDirectory networkDirectory;
    private UserAccountDirectory userAccountDirectory;
    private EmployeeDirectory employeeDirectory;
    private OrganizationDirectory organizationDirectory;
    private Enterprise.EnterpriseType enterpriseType;

    public static EcoSystem getInstance() {
        if (business == null) {
            business = new EcoSystem();
        }
        return business;
    }

    private EcoSystem() {
        networkDirectory = new NetworkDirectory();
        organizationDirectory = new OrganizationDirectory();
        userAccountDirectory = new UserAccountDirectory();
        employeeDirectory = new EmployeeDirectory();
    }

    public NetworkDirectory getNetworkDirectory() {
        return networkDirectory;
    }

    public void setNetworkDirectory(NetworkDirectory networkDirectory) {
        this.networkDirectory = networkDirectory;
    }

    public boolean checkIfUserIsUnique(String userName) {
        if (!this.getUserAccountDirectory().checkIfUsernameIsUnique(userName)) {
            return false;
        }
        for (Network network : this.networkDirectory.getNetworkList()) {
            for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                if (!enterprise.getUserAccountDirectory().checkIfUsernameIsUnique(userName)) {
                        return false;
                    }
                for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                    if (!organization.getUserAccountDirectory().checkIfUsernameIsUnique(userName)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public void setEmployeeDirectory(EmployeeDirectory employeeDirectory) {
        this.employeeDirectory = employeeDirectory;
    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    public Enterprise.EnterpriseType getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(Enterprise.EnterpriseType enterpriseType) {
        this.enterpriseType = enterpriseType;
    }
}
